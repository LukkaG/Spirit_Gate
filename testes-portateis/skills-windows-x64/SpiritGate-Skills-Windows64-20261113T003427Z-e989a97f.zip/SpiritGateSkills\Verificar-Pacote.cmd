@echo off
cd /d "%~dp0"
"%~dp0runtime\bin\java.exe" -cp "%~dp0app\spiritgate-skills.jar" SkillsLocalPreviewProbe "%~dp0"
if errorlevel 1 goto failed
"%~dp0runtime\bin\java.exe" -cp "%~dp0app\spiritgate-skills.jar" SkillsLiveSwitchProbe "%~dp0"
:failed
pause
