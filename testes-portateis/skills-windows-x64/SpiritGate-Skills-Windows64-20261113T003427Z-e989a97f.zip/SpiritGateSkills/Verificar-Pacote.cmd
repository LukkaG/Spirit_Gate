@echo off
cd /d "%~dp0."
"%~dp0runtime\bin\java.exe" -cp "%~dp0app\spiritgate-skills.jar" SkillsLocalPreviewProbe "%~dp0."
if errorlevel 1 goto failed
"%~dp0runtime\bin\java.exe" -cp "%~dp0app\spiritgate-skills.jar" SkillsLiveSwitchProbe "%~dp0."
if errorlevel 1 goto failed
echo SKILLS_PACKAGE_PASS
pause
exit /b 0
:failed
echo SKILLS_PACKAGE_FAILED
pause
exit /b 1
