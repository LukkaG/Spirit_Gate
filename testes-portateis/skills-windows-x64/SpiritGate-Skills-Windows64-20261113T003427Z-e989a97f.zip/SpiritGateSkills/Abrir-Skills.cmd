@echo off
cd /d "%~dp0."
"%~dp0runtime\bin\java.exe" -jar "%~dp0app\spiritgate-skills.jar" "%~dp0."
if errorlevel 1 pause
